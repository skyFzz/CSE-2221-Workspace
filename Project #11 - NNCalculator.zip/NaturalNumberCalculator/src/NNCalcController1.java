import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;

/**
 * Controller class.
 *
 * @author Henry Zhou
 */
public final class NNCalcController1 implements NNCalcController {

    /**
     * Model object.
     */
    private final NNCalcModel model;

    /**
     * View object.
     */
    private final NNCalcView view;

    /**
     * Useful constants.
     */
    private static final NaturalNumber TWO = new NaturalNumber2(2),
            INT_LIMIT = new NaturalNumber2(Integer.MAX_VALUE);

    /**
     * Updates this.view to display this.model, and to allow only operations
     * that are legal given this.model.
     *
     * @param model
     *            the model
     * @param view
     *            the view
     * @ensures [view has been updated to be consistent with model]
     */
    private static void updateViewToMatchModel(NNCalcModel model,
            NNCalcView view) {

        //get model info
        NaturalNumber top = model.top();
        NaturalNumber bot = model.bottom();

        //updates view to reflect changes in model
        view.updateTopDisplay(top);
        view.updateBottomDisplay(bot);

        /*
         * updates legal operations: subtract, divide, power, root
         */
        //subtract
        boolean subtractLegal = true;
        if (top.compareTo(bot) < 0) {
            subtractLegal = false;
            view.updateSubtractAllowed(subtractLegal);
        }
        view.updateSubtractAllowed(subtractLegal);

        //divide
        boolean divideLegal = true;
        if (bot.isZero()) {
            divideLegal = false;
            view.updateDivideAllowed(divideLegal);
        }
        view.updateDivideAllowed(divideLegal);

        //power
        boolean powerLegal = true;
        if (bot.compareTo(INT_LIMIT) > 0) {
            powerLegal = false;
            view.updatePowerAllowed(powerLegal);
        }
        view.updatePowerAllowed(powerLegal);

        //root
        boolean rootLegal = true;
        if (bot.compareTo(TWO) < 0 || bot.compareTo(INT_LIMIT) > 0) {
            rootLegal = false;
            view.updateRootAllowed(rootLegal);
        }
        view.updateRootAllowed(rootLegal);

    }

    /**
     * Constructor.
     *
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public NNCalcController1(NNCalcModel model, NNCalcView view) {
        this.model = model;
        this.view = view;
        updateViewToMatchModel(model, view);

    }

    @Override
    public void processClearEvent() {
        /*
         * Get alias to bottom from model
         */
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        bottom.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processSwapEvent() {
        /*
         * Get aliases to top and bottom from model
         */
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();
        /*
         * Update model in response to this event
         */
        NaturalNumber temp = top.newInstance();
        temp.transferFrom(top);
        top.transferFrom(bottom);
        bottom.transferFrom(temp);
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    @Override
    public void processEnterEvent() {

        //get aliases to top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //upate model
        top.copyFrom(bottom);

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddEvent() {

        //get aliases to top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //upate model
        bottom.add(top);
        top.clear();

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processSubtractEvent() {

        //get aliases to top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //upate model
        top.subtract(bottom);
        bottom.transferFrom(top);

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processMultiplyEvent() {

        //get aliases to top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //upate model
        bottom.multiply(top);
        top.clear();

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processDivideEvent() {

        //get aliases to top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //upate model
        NaturalNumber remain = top.divide(bottom);
        bottom.transferFrom(top);
        top.transferFrom(remain);

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processPowerEvent() {

        //get aliases to top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        /*
         * upate model, the requires clause says that the bottom has to be less
         * than or equal to INT_LIMIT
         */
        top.power(bottom.toInt());
        bottom.transferFrom(top);

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processRootEvent() {

        //get aliases to top and bottom
        NaturalNumber top = this.model.top();
        NaturalNumber bottom = this.model.bottom();

        //upate model
        top.root(bottom.toInt());
        bottom.transferFrom(top);

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

    @Override
    public void processAddNewDigitEvent(int digit) {

        //get aliases to bottom
        NaturalNumber bottom = this.model.bottom();

        //upate model
        bottom.multiplyBy10(digit);

        //upate view
        updateViewToMatchModel(this.model, this.view);

    }

}
