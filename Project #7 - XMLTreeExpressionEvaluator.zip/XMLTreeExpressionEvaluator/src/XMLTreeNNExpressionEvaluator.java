import static components.utilities.Reporter.fatalErrorToConsole;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Henry Zhou
 *
 */
public final class XMLTreeNNExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluator() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";

        /*
         * If the root is an operator, it has exactly two nested tags, otherwise
         * the root is an operand.
         */
        NaturalNumber result = new NaturalNumber2();
        NaturalNumber zero = new NaturalNumber2(0);

        if (!exp.label().equals("number")) {
            //the root has two child nodes, applying recursion for each value
            NaturalNumber left = evaluate(exp.child(0));
            NaturalNumber right = evaluate(exp.child(1));

            if (exp.label().equals("plus")) {
                left.add(right);
                result.copyFrom(left);
            } else if (exp.label().equals("minus")) {
                //check if the result might be negatvie, and report fatal error
                if (left.compareTo(right) < 0) {
                    fatalErrorToConsole(
                            "The result is negative, try different numbers.");
                }
                left.subtract(right);
                result.copyFrom(left);
            } else if (exp.label().equals("times")) {
                left.multiply(right);
                result.copyFrom(left);
            } else if (exp.label().equals("divide")) {
                //check if divide by 0 situation exists, and report fatal error
                if (right.equals(zero)) {
                    fatalErrorToConsole(
                            "Divide by 0 is not allowed, try different numbers.");
                }
                left.divide(right);
                result.copyFrom(left);
            } else if (exp.label().equals("mod")) {
                //check if mod by 0 situation exists, and report fatal error
                if (right.equals(zero)) {
                    fatalErrorToConsole(
                            "Mod by 0 is not allowed, try different numbers.");
                }
                NaturalNumber remain = left.divide(right);
                result.copyFrom(remain);
            } else if (exp.label().equals("power")) {
                left.power(right.toInt());
                result.copyFrom(left);
            } else if (exp.label().equals("root")) {
                //check if the number taken root from is negative, and report fatal
                if (left.compareTo(zero) < 0) {
                    fatalErrorToConsole(
                            "The number taken nth root must not be negative.");
                }
                left.root(right.toInt());
                result.copyFrom(left);
            }

        } else {
            NaturalNumber temp = new NaturalNumber2(
                    exp.attributeValue("value"));
            result.copyFrom(temp);

        }

        return result;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}
