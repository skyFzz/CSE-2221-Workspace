import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Compute roots using NewTon Iteration.
 *
 * @author Henry Zhou
 *
 */
public final class Newton5 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Newton5() {
    }

    /**
     * Computes estimate of square root of x to within relative error.
     *
     * @param x
     *            positive number, including 0, to compute square root of
     * @param error
     *            relative error, to restrain how precise the result is
     *
     * @return estimate of square root
     */
    private static double sqrt(double x, double error) {
        double rGuess = x;

        //when x = 0, do not attempt to compute it
        if (x == 0) {
            rGuess = 0;
        } else {
            //Newton iteration algorithm
            while (Math.abs(rGuess * rGuess - x) / x > error * error) {
                rGuess = (rGuess + x / rGuess) / 2;
            }
        }

        return rGuess;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //initialize the input value in order to enter the while loop
        double inputNum = 0;
        while (inputNum >= 0) {
            out.print("Enter a new value of x you want me to calculate: ");
            inputNum = in.nextDouble();
            //check whether the user want to quit after each input
            if (inputNum >= 0) {
                //ask for relative error as the second parameter of method sqrt()
                out.print("Enter the relative error you want me for result: ");
                double relativeError = in.nextDouble();

                //ask for a root k and report the k-th root of x
                out.print("Enter a root k: ");
                //int rootK = in.nextInteger();

                //output the value
                out.println("The square root of " + inputNum + " is "
                        + sqrt(inputNum, relativeError)
                        + " using Newton iteration!");
            }

        }

        out.println("Time to quit!");
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
