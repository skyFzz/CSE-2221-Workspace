import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Compute roots using NewTon Iteration.
 *
 * @author Henry Zhou
 *
 */
public final class Newton1 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Newton1() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @return estimate of square root
     */
    private static double sqrt(double x) {

        //numeric constant of relative error
        final double relativeError = 0.0001;
        double rGuess = x;

        //Newton iteration algorithm
        while (Math.abs(rGuess * rGuess - x) / x > relativeError
                * relativeError) {
            rGuess = (rGuess + x / rGuess) / 2;
        }

        return rGuess;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print(
                "Do you wish to calculate another square root? Enter 'y' to proceed: ");
        String response = in.nextLine();
        while (response.equals("y")) {
            out.print("Enter a new value of x you want me to calculate: ");
            double inputNum = in.nextDouble();
            //output the value
            out.println("The square root of " + inputNum + " is "
                    + sqrt(inputNum) + " using Newton iteration!");
            out.print("Another square root? Enter 'y' to proceed: ");
            response = in.nextLine();

        }

        out.println("Time to quit!");
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
