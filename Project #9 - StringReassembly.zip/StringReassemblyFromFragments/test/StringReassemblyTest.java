import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    /*
     * Test of combination
     */
    @Test
    public void testCombination_CGAGGTAGT_AGTAGAACG_3() {
        String str1 = "CGAGGTAGT";
        String str2 = "AGTAGAACG";
        int overlap = 3;
        String concatExpected = "CGAGGTAGTAGAACG";
        String concat = StringReassembly.combination(str1, str2, overlap);
        assertEquals(concatExpected, concat);

    }

    @Test
    public void testCombination_BREAKEAKING_EAKINGBAD_4() {
        String str1 = "BREAKING";
        String str2 = "KINGBAD";
        int overlap = 4;
        String concatExpected = "BREAKINGBAD";
        String concat = StringReassembly.combination(str1, str2, overlap);
        assertEquals(concatExpected, concat);

    }

    @Test
    public void testCombination_SOULGOODMAN_13() {
        String str1 = "BETTERCALLSOUL";
        String str2 = "ETTERCALLSOULGOODMAN";
        int overlap = 13;
        String concatExpected = "BETTERCALLSOULGOODMAN";
        String concat = StringReassembly.combination(str1, str2, overlap);
        assertEquals(concatExpected, concat);

    }

    @Test
    public void testCombination_0() {
        String str1 = "KAISAISKASS";
        String str2 = "DAUGHTER";
        int overlap = 0;
        String concatExpected = "KAISAISKASSDAUGHTER";
        String concat = StringReassembly.combination(str1, str2, overlap);
        assertEquals(concatExpected, concat);

    }

    /*
     * Test of addToSetAvoidingSubstrings
     */
    @Test
    public void testAddToSetAvoidingSubstring_Starwar() {
        Set<String> strSet = new Set1L<>();
        strSet.add("Star");
        strSet.add("war");
        strSet.add("City of Stars");

        String str = "Starwar";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        Set<String> strSetExpected = new Set1L<>();
        strSetExpected.add(str);
        strSetExpected.add("City of Stars");

        assertEquals(strSetExpected, strSet);
    }

    @Test
    public void testAddToSetAvoidingSubstring_City() {
        Set<String> strSet = new Set1L<>();
        strSet.add("Star");
        strSet.add("war");
        strSet.add("City of Stars");

        String str = "City";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        Set<String> strSetExpected = new Set1L<>();
        strSetExpected.add("Star");
        strSetExpected.add("war");
        strSetExpected.add("City of Stars");

        assertEquals(strSetExpected, strSet);
    }

    @Test
    public void testAddToSetAvoidingSubstring_CityOfStarsWar() {
        Set<String> strSet = new Set1L<>();
        strSet.add("Star");
        strSet.add("war");
        strSet.add("City of Stars");

        String str = "City of Starswar";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        Set<String> strSetExpected = new Set1L<>();
        strSetExpected.add(str);

        assertEquals(strSetExpected, strSet);
    }

    @Test
    public void testAddToSetAvoidingSubstring_StarGuardian() {
        Set<String> strSet = new Set1L<>();
        strSet.add("StarGuardian");

        String str = "Star";
        StringReassembly.addToSetAvoidingSubstrings(strSet, str);
        Set<String> strSetExpected = new Set1L<>();
        strSetExpected.add("StarGuardian");

        assertEquals(strSetExpected, strSet);
    }

    /*
     * Test of linesFromInput
     */
    @Test
    public void testLinesFromInput1() {
        SimpleReader input = new SimpleReader1L("testPrintWithLineSeparators1");
        Set<String> setExpected = new Set1L<>();
        setExpected.add("Hello");
        setExpected.add("World!");

        assertEquals(setExpected, StringReassembly.linesFromInput(input));

    }

    @Test
    public void testLinesFromInput2() {
        SimpleReader input = new SimpleReader1L("testPrintWithLineSeparators2");
        Set<String> setExpected = new Set1L<>();
        setExpected.add("Hello, World!");

        assertEquals(setExpected, StringReassembly.linesFromInput(input));

    }

    @Test
    public void testLinesFromInput3() {
        SimpleReader input = new SimpleReader1L("testPrintWithLineSeparators3");
        Set<String> setExpected = new Set1L<>();
        setExpected.add("Hello,");
        setExpected.add("World!");
        setExpected.add("Dance,");
        setExpected.add("With,");
        setExpected.add("Me!");

        assertEquals(setExpected, StringReassembly.linesFromInput(input));

    }

    @Test
    public void testLinesFromInput4() {
        SimpleReader input = new SimpleReader1L("testPrintWithLineSeparators4");
        Set<String> setExpected = new Set1L<>();
        setExpected.add("Hello!");
        assertEquals(setExpected, StringReassembly.linesFromInput(input));

    }

    /*
     * Test of printWithLineSeparators
     */
    @Test
    public void testPrintWithLineSeparators1() {
        SimpleWriter write = new SimpleWriter1L("testPrintWithLineSeparators1");
        String text = "Hello~World!";
        StringReassembly.printWithLineSeparators(text, write);
        SimpleReader read = new SimpleReader1L("testPrintWithLineSeparators1");

        String output = "";
        while (!read.atEOS()) {
            output += read.nextLine() + "/n";
        }
        assertEquals("Hello/nWorld!/n", output);

        write.close();
        read.close();
    }

    @Test
    public void testPrintWithLineSeparators2() {
        SimpleWriter write = new SimpleWriter1L("testPrintWithLineSeparators2");
        String text = "~Hello, World!";
        StringReassembly.printWithLineSeparators(text, write);
        SimpleReader read = new SimpleReader1L("testPrintWithLineSeparators2");

        String output = "";
        while (!read.atEOS()) {
            output += read.nextLine() + "/n";
        }
        assertEquals("/nHello, World!/n", output);

        write.close();
        read.close();
    }

    @Test
    public void testPrintWithLineSeparators3() {
        SimpleWriter write = new SimpleWriter1L("testPrintWithLineSeparators3");
        String text = "Hello,~World!~Dance,~With,~Me!";
        StringReassembly.printWithLineSeparators(text, write);
        SimpleReader read = new SimpleReader1L("testPrintWithLineSeparators3");

        String output = "";
        while (!read.atEOS()) {
            output += read.nextLine() + "/n";
        }
        assertEquals("Hello,/nWorld!/nDance,/nWith,/nMe!/n", output);

        write.close();
        read.close();
    }

    @Test
    public void testPrintWithLineSeparators4() {
        SimpleWriter write = new SimpleWriter1L("testPrintWithLineSeparators4");
        String text = "Hello!";
        StringReassembly.printWithLineSeparators(text, write);
        SimpleReader read = new SimpleReader1L("testPrintWithLineSeparators4");

        String output = "";
        while (!read.atEOS()) {
            output += read.nextLine() + "/n";
        }
        assertEquals("Hello!/n", output);

        write.close();
        read.close();
    }
}
