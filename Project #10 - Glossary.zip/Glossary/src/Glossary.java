import java.util.Comparator;

import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * This project transforms an input file with words and definitions to a batch
 * of html files which starts with an index page that has all the terms listed
 * alphabetically, and by clicking each term you can see each of their
 * definitions.
 *
 * @author Henry Zhou
 *
 */
public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Comparator created in order to invoke sort method to sort terms
     * alphabetically.
     *
     * @author zhouhaoling
     * @return a negative value if s1 is less than s2, positive if s1 is greater
     *         than s2, 0 if s1 is equal to s2
     */
    private static class TermsAlpha implements Comparator<String> {
        @Override
        public int compare(String s1, String s2) {
            return s1.compareTo(s2);
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        char start = text.charAt(position);
        //true if starts with separator, otherwise it is a word
        boolean isSeparator = separators.contains(start);

        int endIndex = position + 1;
        while (endIndex < text.length()
                && isSeparator == separators.contains(text.charAt(endIndex))) {
            endIndex++;
        }

        return text.substring(position, endIndex);
    }

    /**
     * Print one page for one term with its definition and return the word.
     *
     * @param terms
     *            the list of terms that's already sorted
     * @param map
     *            terms and their according definitions
     * @return the term that is dequeued
     * @ensures ouptut one individual page and return the term
     */
    private static String getOneTerm(Queue<String> terms,
            Map<String, String> map) {

        Set<Character> separators = new Set1L<>();
        separators.add(' ');
        separators.add(',');
        String term = terms.dequeue();
        String definition = map.value(term);
        SimpleWriter out = new SimpleWriter1L("data/" + term + ".html");

        out.println("<html>");
        out.println("<head>");
        out.println("<title>" + term + "</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2><b><i><font color=\"red\">" + term
                + "</font></i></b></h2>");
        /*
         * If one of the terms in the glossary is a substring of the definition,
         * link the term to its definition.
         */
        out.print("<blockquote>");
        int position = 0;
        while (position < definition.length()) {
            String nextWord = nextWordOrSeparator(definition, position,
                    separators);

            boolean isInGlossary = false;
            //use map to check instead of queue because the queue is changing
            for (Pair<String, String> x : map) {
                String key = x.key();
                if (nextWord.equals(key)) {
                    //print the word with link tags added to it
                    out.print("<a href=\"" + nextWord + ".html\">" + nextWord
                            + "</a>");
                    isInGlossary = true;
                }
            }
            //if the word is not in the glossary, just print the word
            if (!isInGlossary) {
                out.print(nextWord);

            }

            String nextSeparator = "";
            //aviod the index out of bound
            if (position + nextWord.length() < definition.length()) {
                //increment the position based on the length of the next separator
                nextSeparator = nextWordOrSeparator(definition,
                        position + nextWord.length(), separators);
                out.print(nextSeparator);
            }

            position += nextWord.length() + nextSeparator.length();

        }
        out.println("</blockquote>");
        out.println("<hr />");
        out.println("<p>Return to <a href=\"index.html\">index</a>.</p>");
        out.println("</body>");
        out.println("</html>");
        out.close();

        return term;

    }

    /**
     * Get all the terms and definitions from the input files.
     *
     * @param in
     *            read the input file
     * @param terms
     *            the list of terms that's already sorted
     * @param map
     *            terms and their according definitions
     * @replaces terms and map
     * @requires in. is open; terms and map are clear
     * @ensures in. is not closed
     */
    private static void getTermsAndDefinitions(SimpleReader in,
            Queue<String> terms, Map<String, String> map) {

        while (!in.atEOS()) {
            String term = in.nextLine();
            String definition = in.nextLine();
            String next = in.nextLine();
            //StringBuilder is a option to avoid this bug
            while (!next.equals("")) {
                definition = definition + " " + next;
                next = in.nextLine();
            }

            terms.enqueue(term);
            map.add(term, definition);
        }
    }

    /**
     * Output the indexPage to the designated folder.
     *
     * @param out
     *            output to the designated html file
     * @param terms
     *            the list of terms that's already sorted
     * @requires out. is open
     * @ensures out. is not closed and terms is restored
     */
    private static void printIndexPage(SimpleWriter out, Queue<String> terms) {

        Comparator<String> termOrder = new TermsAlpha();
        terms.sort(termOrder);

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Henry Zhou's Glossary</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Henry Zhou's Glossary</h2>");
        out.println("<hr />");
        out.println("<h3>Index</h3>");
        out.println("<u1>");

        Queue<String> tempTerms = terms.newInstance();
        while (terms.length() > 0) {
            String word = terms.dequeue();
            tempTerms.enqueue(word);
            out.println(
                    "<li><a href=\"" + word + ".html\">" + word + "</a></li>");

        }
        //restore the original queue
        terms.transferFrom(tempTerms);

        out.println("</ul>");
        out.println("</body>");
        out.println("</html>");

    }

    /**
     * Main method. Create reader and writer objects. Get information from input
     * files and output them into html files.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //ask for the input file
        out.println("May I have a input file?");
        String inputFile = in.nextLine();

        //ask for the output folder
        out.println("May I also have a output folder?");
        String outputFolder = in.nextLine();

        //input the terms into a SimpleReader object
        SimpleReader read = new SimpleReader1L(inputFile);

        //output the html content into a SimpleWriter object
        SimpleWriter write = new SimpleWriter1L(outputFolder + "/index.html");

        /*
         * Get terms and definition stored, using two major components: Queue &
         * Map. Queue is used to store terms alphabetically, and Map is used to
         * store terms and their according definitions.
         */
        Queue<String> terms = new Queue1L<>();
        Map<String, String> dictionary = new Map1L<>();
        getTermsAndDefinitions(read, terms, dictionary);

        //output the index page
        printIndexPage(write, terms);

        //output the separate pages for each of the terms with their definitions
        Queue<String> tempTerms = terms.newInstance();
        while (terms.length() > 0) {
            String term = getOneTerm(terms, dictionary);
            //since the method would dequeue one term, restore it
            tempTerms.enqueue(term);

        }
        terms.transferFrom(tempTerms);

        in.close();
        out.close();
    }

}
