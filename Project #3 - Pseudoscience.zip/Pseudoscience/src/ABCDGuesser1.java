import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class ABCDGuesser1 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser1() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        //ask for an input first, do not assume the user will provide a number
        out.print("A positive real number please: ");
        String input = in.nextLine();

        //initialize for exiting the loop check
        boolean isPosRealNum = false;
        //initialize for enough scope to return
        double inputRealNum = 0;

        //check if the input satisfies both if-conditions, otherwise keep asking
        while (!isPosRealNum) {
            if (FormatChecker.canParseDouble(input)) {
                inputRealNum = Double.parseDouble(input);
                if (inputRealNum > 0) {
                    isPosRealNum = true;
                } else {
                    out.print(
                            "Enter a positive real number please! Try again: ");
                    input = in.nextLine();
                }
            } else {
                out.print("Enter a number please! Try again: ");
                input = in.nextLine();
            }
        }

        return inputRealNum;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {

        //use the method implemented already to get a positive real number
        double posRealNum = getPositiveDouble(in, out);

        //check if the number is equal to 1.0
        while (posRealNum == 1.0) {
            out.print(
                    "A positive real number not equal to 1.0 please! Try again:");
            posRealNum = getPositiveDouble(in, out);
        }

        return posRealNum;

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.println(
                "Welcome to pseudosicence! What constant \u00B5 should be approximated?");
        double muConstant = getPositiveDouble(in, out);

        out.println(
                "Great choice! Now please enter four personal numbers in turn. ");

        out.print("First personal number. ");
        double w = getPositiveDoubleNotOne(in, out);

        out.print("Second personal number. ");
        double x = getPositiveDoubleNotOne(in, out);

        out.print("Third personal number. ");
        double y = getPositiveDoubleNotOne(in, out);

        out.print("Forth personal number. ");
        double z = getPositiveDoubleNotOne(in, out);

        //initialize the magic numbers that are in the pool and store them
        final double five = 5.0;
        final double four = 4.0;
        final double three = 3.0;
        final double two = 2.0;
        double[] numPool = { -five, -four, -three, -two, -1.0, -1 / two,
                -1 / three, -1 / four, 0, 1 / four, 1 / three, 1 / two, 1.0,
                two, three, four, five };
        //store the size of the pool
        int poolSize = numPool.length;

        /*
         * Find the combination of exponents that minimizes the error of
         * estimate. We need four index variables that iterate through the
         * number pool.
         */

        //create an array of integers to act as a counter
        final int length = 4;
        int[] indexesOfExpo = new int[length];
        //allocate a double array to hold the four exponents: a, b, c, d
        double[] expoValue = new double[length];
        //allocate a double array to hold the result of power calculation
        double[] power = new double[length];

        final double percentage = 100;
        double approximate = 0;
        final int place = 3;
        while (indexesOfExpo[0] < poolSize) {
            power[0] = Math.pow(w, numPool[indexesOfExpo[0]]);
            indexesOfExpo[1] = 0;
            indexesOfExpo[0]++;
            while (indexesOfExpo[1] < poolSize) {
                power[1] = Math.pow(x, numPool[indexesOfExpo[1]]);
                indexesOfExpo[2] = 0;
                indexesOfExpo[1]++;
                while (indexesOfExpo[2] < poolSize) {
                    power[2] = Math.pow(y, numPool[indexesOfExpo[2]]);
                    indexesOfExpo[place] = 0;
                    indexesOfExpo[2]++;
                    while (indexesOfExpo[place] < poolSize) {
                        power[place] = Math.pow(z,
                                numPool[indexesOfExpo[place]]);
                        double tempApproximate = power[0] * power[1] * power[2]
                                * power[place];

                        while (Math.abs(tempApproximate - muConstant) < Math
                                .abs(approximate - muConstant)) {
                            approximate = tempApproximate;
                            expoValue[0] = numPool[indexesOfExpo[0] - 1];
                            expoValue[1] = numPool[indexesOfExpo[1] - 1];
                            expoValue[2] = numPool[indexesOfExpo[2] - 1];
                            expoValue[place] = numPool[indexesOfExpo[place]];

                        }
                        indexesOfExpo[place]++;

                    }

                }

            }

        }

        double relativeError = Math.abs((approximate - muConstant) / muConstant)
                * percentage;
        out.println("We have finished calculations!");
        out.println("The exponent a is: " + expoValue[0]);
        out.println("The exponent b is: " + expoValue[1]);
        out.println("The exponent c is: " + expoValue[2]);
        out.println("The exponent d is: " + expoValue[place]);
        out.println("The best approximation is " + approximate);
        out.println("The relative error is: " + relativeError + "%");

        in.close();
        out.close();
    }

}
