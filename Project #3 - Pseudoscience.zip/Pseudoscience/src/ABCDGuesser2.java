import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class ABCDGuesser2 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser2() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        //ask for an input first, do not assume the user will provide a number
        out.print("A positive real number please: ");
        String input = in.nextLine();

        //initialize for exiting the loop check
        boolean isPosRealNum = false;
        //initialize for enough scope to return
        double inputRealNum = 0;

        //check if the input satisfies both if-conditions, otherwise keep asking
        while (!isPosRealNum) {
            if (FormatChecker.canParseDouble(input)) {
                inputRealNum = Double.parseDouble(input);
                if (inputRealNum > 0) {
                    isPosRealNum = true;
                } else {
                    out.print(
                            "Enter a positive real number please! Try again: ");
                    input = in.nextLine();
                }
            } else {
                out.print("Enter a number please! Try again: ");
                input = in.nextLine();
            }
        }

        return inputRealNum;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {

        //use the method implemented already to get a positive real number
        double posRealNum = getPositiveDouble(in, out);

        //check if the number is equal to 1.0
        while (posRealNum == 1.0) {
            out.print(
                    "A positive real number not equal to 1.0 please! Try again:");
            posRealNum = getPositiveDouble(in, out);
        }

        return posRealNum;

    }

    /**
     * Find the combination of exponents that minimizes the error of estimate.
     * We need four index variables that iterate through the number pool.
     *
     * @param pool
     *            the number pool
     * @param w
     *            one of the personal numbers
     * @param x
     *            one of the personal numbers
     * @param y
     *            one of the personal numbers
     * @param z
     *            one of the personal numbers
     * @param muConstant
     *            the universal constant input
     * @return a double array that includes the approximate and the exponents
     */
    private static double[] getApproximateAndExpoValue(double[] pool, double w,
            double x, double y, double z, double muConstant) {
        //store the size of the pool
        int size = pool.length;

        //create an array of integers to act as a counter
        final int length = 4;
        int[] indexExpo = new int[length];
        //allocate a double array to hold the four exponents: a, b, c, d
        double[] expoValue = new double[length];
        //allocate a double array to hold the result of power calculation
        double[] power = new double[length];

        double approximate = 0;
        final int len = 3;

        for (indexExpo[0] = 0; indexExpo[0] < size; indexExpo[0]++) {
            power[0] = Math.pow(w, pool[indexExpo[0]]);
            indexExpo[1] = 0;

            for (indexExpo[1] = 0; indexExpo[1] < size; indexExpo[1]++) {
                power[1] = Math.pow(x, pool[indexExpo[1]]);
                indexExpo[2] = 0;

                for (indexExpo[2] = 0; indexExpo[2] < size; indexExpo[2]++) {
                    power[2] = Math.pow(y, pool[indexExpo[2]]);
                    indexExpo[len] = 0;

                    for (indexExpo[len] = 0; indexExpo[len] < size; indexExpo[len]++) {
                        power[len] = Math.pow(z, pool[indexExpo[len]]);
                        double tempApproximate = power[0] * power[1] * power[2]
                                * power[len];

                        while (Math.abs(tempApproximate - muConstant) < Math
                                .abs(approximate - muConstant)) {
                            approximate = tempApproximate;
                            expoValue[0] = pool[indexExpo[0] - 1];
                            expoValue[1] = pool[indexExpo[1] - 1];
                            expoValue[2] = pool[indexExpo[2] - 1];
                            expoValue[len] = pool[indexExpo[len]];

                        }

                    }

                }

            }

        }

        final int fiveValues = 5;
        double[] approximateAndExpoValue = new double[fiveValues];
        approximateAndExpoValue[0] = expoValue[0];
        approximateAndExpoValue[1] = expoValue[1];
        approximateAndExpoValue[2] = expoValue[2];
        approximateAndExpoValue[len] = expoValue[len];
        approximateAndExpoValue[len + 1] = approximate;

        return approximateAndExpoValue;

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.println(
                "Welcome to pseudosicence! What constant \u00B5 should be approximated?");
        double muConstant = getPositiveDouble(in, out);

        out.println(
                "Great choice! Now please enter four personal numbers in turn. ");

        out.print("First personal number. ");
        double w = getPositiveDoubleNotOne(in, out);

        out.print("Second personal number. ");
        double x = getPositiveDoubleNotOne(in, out);

        out.print("Third personal number. ");
        double y = getPositiveDoubleNotOne(in, out);

        out.print("Forth personal number. ");
        double z = getPositiveDoubleNotOne(in, out);

        //initialize the magic numbers that are in the pool and store them
        final double five = 5.0;
        final double four = 4.0;
        final double three = 3.0;
        final double two = 2.0;
        final double percentage = 100;
        double[] numPool = { -five, -four, -three, -two, -1.0, -1 / two,
                -1 / three, -1 / four, 0, 1 / four, 1 / three, 1 / two, 1.0,
                two, three, four, five };

        //call the method to get the value of approximation and each exponent
        double[] approximateAndExpo = getApproximateAndExpoValue(numPool, w, x,
                y, z, muConstant);
        final int length = 3;
        double relativeError = Math
                .abs((approximateAndExpo[length + 1] - muConstant) / muConstant)
                * percentage;
        out.println("We have finished calculations!");
        out.println("The exponent a is: " + approximateAndExpo[0]);
        out.println("The exponent b is: " + approximateAndExpo[1]);
        out.println("The exponent c is: " + approximateAndExpo[2]);
        out.println("The exponent d is: " + approximateAndExpo[length]);
        out.println(
                "The best approximation is " + approximateAndExpo[length + 1]);
        out.println("The relative error is: " + relativeError + "%");

        in.close();
        out.close();
    }

}
